from setuptools import setup, find_packages
setup(
    name='seleccioninstancias',
    version=0.3,
    license="MIT",
    description="Paquete con una funcion",
    author='Victor Martinez Santiago @vicbox',
#    author_email='victor.santiago@cimat.mx',
    url='https://github.com/VicBoxMS/SeleccionInstancias',
    install_requires=['numpy'],
    packages=find_packages()
)
