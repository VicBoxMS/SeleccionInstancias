# SeleccionInstancias
 Contiene funciones para realizar la seleccion de instancias.
